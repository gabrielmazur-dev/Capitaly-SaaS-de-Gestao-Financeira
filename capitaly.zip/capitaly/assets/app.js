(function(){
"use strict";
var $=function(s,c){return (c||document).querySelector(s)};
var esc=function(s){return String(s).replace(/[&<>"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]})};
var brl=function(n){return (+n).toLocaleString("pt-BR",{style:"currency",currency:"BRL"})};
var num=function(n,d){n=+n;return isFinite(n)?n.toLocaleString("pt-BR",{minimumFractionDigits:0,maximumFractionDigits:d==null?2:d}):"0"};
var fd=function(s){var p=s.split("-");return p[2]+"/"+p[1]+"/"+p[0]};
var RES={tx:"lancamentos",div:"dividas",inv:"investimentos",metas:"metas"};
function api(p,o){o=o||{};var h={"X-Requested-With":"capitaly"},c={method:o.method||"GET",credentials:"same-origin",headers:h};
 if(o.body){h["Content-Type"]="application/json";c.body=JSON.stringify(o.body)}
 return fetch("api/"+p,c).then(function(r){return r.json().catch(function(){return {}}).then(function(j){
  if(!r.ok){var cs=j.campos||{},ks=Object.keys(cs),e=new Error(ks.length?cs[ks[0]]:(j.erro||"Erro no servidor ("+r.status+")."));e.campos=cs;e.status=r.status;throw e}return j})})}
var ic=function(n){return '<svg class="i" aria-hidden="true"><use href="assets/icons.svg#i-'+n+'"/></svg>'};
var tt;function toast(t){var e=$("#tst");e.textContent=t;e.classList.add("on");clearTimeout(tt);tt=setTimeout(function(){e.classList.remove("on")},3500)}

var U=null,D=null,V="dash";
var blank=function(){return {tx:[],div:[],inv:[],metas:[],vei:null}};

function formHTML(id,fs,btn){return '<form id="'+id+'" class="fg" novalidate>'+fs.map(function(f){
 var i=id+"_"+f.k,c=f.o?'<select id="'+i+'" name="'+f.k+'">'+f.o.map(function(o){return "<option>"+o+"</option>"}).join("")+"</select>"
 :'<input id="'+i+'" name="'+f.k+'" type="'+f.t+'"'+(f.t==="number"?' step="any" inputmode="decimal"':"")+(f.v!=null?' value="'+esc(f.v)+'"':"")+">";
 return '<div class="f"><label for="'+i+'">'+f.l+"</label>"+c+'<span class="err"></span></div>'}).join("")+'<button class="btn p">'+btn+"</button></form>"}
function read(form,fs){var ok=true,o={};
 fs.forEach(function(f){var el=form.elements[f.k],er=el.parentNode.querySelector(".err"),v=el.value.trim(),m="";
  if(f.o){}else if(f.t==="number"){var n=parseFloat(v.replace(",","."));var mn=f.min==null?0.01:f.min;
   if(v===""||isNaN(n))m="Informe um número.";else if(n<mn)m=mn===0?"Use 0 ou mais.":"Use um valor a partir de "+mn+".";else v=n}
  else if(f.t==="date"){if(!v)m="Informe a data."}else if(!v)m="Campo obrigatório.";
  er.textContent=m;el.setAttribute("aria-invalid",m?"true":"false");if(m)ok=false;o[f.k]=v});
 if(!ok){var b=form.querySelector('[aria-invalid="true"]');if(b)b.focus()}return ok?o:null}
var reMail=/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

var mode="login";
function authForm(){var s=mode==="signup";
 $("#tL").setAttribute("aria-selected",!s);$("#tS").setAttribute("aria-selected",s);
 $("#fa").innerHTML=(s?'<div class="f"><label for="an">Nome completo</label><input id="an" name="nome" autocomplete="name"><span class="err"></span></div>':"")+
 '<div class="f"><label for="ae">E-mail</label><input id="ae" name="email" type="email" autocomplete="email"><span class="err"></span></div>'+
 '<div class="f"><label for="as">Senha</label><input id="as" name="senha" type="password" autocomplete="'+(s?"new":"current")+'-password"><span class="err"></span></div>'+
 (s?'<div class="f"><label for="ac">Confirmar senha</label><input id="ac" name="conf" type="password" autocomplete="new-password"><span class="err"></span></div>':"")+
 '<button class="btn p" style="width:100%">'+(s?"Criar conta":"Entrar")+"</button>"}
function fe(f,n,m){var el=f.elements[n];el.parentNode.querySelector(".err").textContent=m||"";el.setAttribute("aria-invalid",m?"true":"false");return !m}
$("#tL").onclick=function(){mode="login";authForm()};$("#tS").onclick=function(){mode="signup";authForm()};
$("#fa").addEventListener("submit",function(e){e.preventDefault();var f=e.target,s=mode==="signup",em=f.elements.email.value.trim().toLowerCase(),pw=f.elements.senha.value,nm="";
 var r=[fe(f,"email",!em?"Informe o e-mail.":!reMail.test(em)?"Use um e-mail válido, como nome@dominio.com.":"")];
 if(s){nm=f.elements.nome.value.trim();r.push(fe(f,"nome",nm.split(/\s+/).length<2?"Informe nome e sobrenome.":""));
  r.push(fe(f,"senha",pw.length<8||!/[A-Za-z]/.test(pw)||!/\d/.test(pw)?"Use 8 caracteres ou mais, com letras e números.":""));
  r.push(fe(f,"conf",f.elements.conf.value!==pw?"As senhas não conferem.":""))}else r.push(fe(f,"senha",pw?"":"Informe a senha."));
 if(r.indexOf(false)>-1){var b=f.querySelector('[aria-invalid="true"]');if(b)b.focus();return}
 var btn=f.querySelector(".btn");btn.disabled=true;
 api("auth.php?acao="+(s?"cadastro":"login"),{method:"POST",body:s?{nome:nm,email:em,senha:pw,conf:f.elements.conf.value}:{email:em,senha:pw}})
 .then(function(r){return start(r.usuario).then(function(){if(s)toast("Conta criada. Bem-vindo ao Capitaly!")})})
 .catch(function(er){var c=er.campos||{},any=false;Object.keys(c).forEach(function(k){if(f.elements[k]){fe(f,k,c[k]);any=true}});if(!any)fe(f,"senha",er.message)})
 .then(function(){btn.disabled=false})});
function start(u){U=u;D=blank();
 return Promise.all(Object.keys(RES).map(function(k){return api(RES[k]+".php").then(function(r){D[k]=r.itens||[]})}).concat([api("veiculo.php").then(function(r){D.vei=r.veiculo||null})]))
 .then(function(){$("#auth").hidden=true;$("#app").hidden=false;if(!location.hash)location.hash="dash";render()})
 .catch(function(er){toast(er.message||"Não foi possível carregar seus dados.")})}
function refresh(){return Promise.all(Object.keys(RES).map(function(k){return api(RES[k]+".php").then(function(r){D[k]=r.itens||[]})}).concat([api("veiculo.php").then(function(r){D.vei=r.veiculo||null})]))}
function out(){api("auth.php?acao=sair",{method:"POST"}).catch(function(){}).then(function(){U=null;D=null;chat=[];$("#app").hidden=true;$("#auth").hidden=false;mode="login";authForm();location.hash=""})}
$("#lo").onclick=out;$("#lo2").onclick=out;

var E={
 tx:{t:"Receitas e despesas",f:[{k:"tipo",l:"Tipo",o:["despesa","receita"]},{k:"desc",l:"Descrição",t:"text"},{k:"cat",l:"Categoria",t:"text"},{k:"valor",l:"Valor (R$)",t:"number"},{k:"data",l:"Data",t:"date"}]},
 div:{t:"Dívidas",f:[{k:"desc",l:"Descrição",t:"text"},{k:"valor",l:"Valor total (R$)",t:"number"},{k:"juros",l:"Juros (% ao mês)",t:"number",min:0},{k:"parcelas",l:"Parcelas",t:"number",min:1},{k:"venc",l:"Vencimento",t:"date"},{k:"status",l:"Status",o:["em dia","atrasada","negociando"]}]},
 inv:{t:"Investimentos",f:[{k:"tipo",l:"Tipo",o:["Renda fixa","Ações","Fundos imobiliários","Cripto","Outro"]},{k:"valor",l:"Valor (R$)",t:"number"},{k:"data",l:"Data",t:"date"},{k:"taxa",l:"Rentab. estimada (% a.a.)",t:"number",min:0}]},
 metas:{t:"Metas financeiras",f:[{k:"obj",l:"Objetivo",t:"text"},{k:"atual",l:"Valor atual (R$)",t:"number",min:0},{k:"alvo",l:"Valor alvo (R$)",t:"number"},{k:"prazo",l:"Prazo",t:"date"}]}
};
function item(k,x){
 if(k==="tx")return [esc(x.desc),esc(x.cat)+" · "+fd(x.data),'<span class="'+(x.tipo==="receita"?"pos":"neg")+'">'+(x.tipo==="receita"?"+ ":"− ")+brl(x.valor)+"</span>",""];
 if(k==="div")return [esc(x.desc),num(x.juros)+"% ao mês · "+x.parcelas+"x de "+brl(x.valor/x.parcelas)+" · vence "+fd(x.venc)+" · "+x.status,brl(x.valor),""];
 if(k==="inv")return [esc(x.tipo),fd(x.data)+" · "+num(x.taxa)+"% a.a. estimado",brl(x.valor),""];
 var p=Math.min(100,x.atual/x.alvo*100),mo=Math.max(1,Math.ceil((new Date(x.prazo+"T12:00")-new Date())/2629800000)),late=new Date(x.prazo+"T12:00")<new Date();
 return [esc(x.obj),Math.round(p)+"% de "+brl(x.alvo)+" · "+(late?"prazo vencido":"guarde "+brl(Math.max(0,x.alvo-x.atual)/mo)+"/mês até "+fd(x.prazo)),brl(x.atual),'<div class="pb" role="img" aria-label="'+Math.round(p)+'% da meta"><i style="width:'+p+'%"></i></div>']}
function sorted(k){var a=D[k].slice();
 if(k==="div")a.sort(function(x,y){return y.juros-x.juros});else if(k==="metas")a.sort(function(x,y){return x.prazo<y.prazo?-1:1});else a.sort(function(x,y){return x.data<y.data?1:-1});return a}
function crud(k){var c=E[k];
 $("#mn").innerHTML="<h1>"+c.t+'</h1><div class="cd">'+formHTML("fm",c.f,"Adicionar")+"</div>"+
 (k==="div"?'<p class="nt" style="margin:-4px 0 12px">Ordem sugerida: pague primeiro a dívida com maior juros (método avalanche) e mantenha o mínimo nas demais.</p>':"")+
 '<div class="cd"><ul class="ls" id="ls"></ul></div>'+(k==="inv"?simInv():"");
 function list(){var a=sorted(k);$("#ls").innerHTML=a.length?a.map(function(x,i){var r=item(k,x);
  return "<li><div><b>"+(k==="div"?'<span class="tag">Prioridade '+(i+1)+"</span>":"")+r[0]+"</b><small>"+r[1]+"</small>"+r[3]+'</div><div class="v">'+r[2]+'</div><button class="x" data-d="'+x.id+'" aria-label="Remover '+r[0].replace(/<[^>]*>/g,"")+'">×</button></li>'}).join(""):'<li class="em">Nada por aqui ainda. Use o formulário acima.</li>'}
 list();
 $("#fm").addEventListener("submit",function(e){e.preventDefault();var o=read(e.target,c.f);if(!o)return;var fm=e.target;api(RES[k]+".php",{method:"POST",body:o}).then(function(r){D[k].push(r.item);fm.reset();list();if(k==="inv")simRun();toast("Adicionado.")}).catch(function(er){toast(er.message)})});
 $("#ls").addEventListener("click",function(e){var b=e.target.closest("[data-d]");if(!b)return;api(RES[k]+".php?id="+encodeURIComponent(b.dataset.d),{method:"DELETE"}).then(function(){D[k]=D[k].filter(function(x){return String(x.id)!==b.dataset.d});list();toast("Removido.")}).catch(function(er){toast(er.message)})});
 if(k==="inv")simWire()}

var SF=[{k:"p",l:"Valor inicial (R$)",t:"number",min:0},{k:"a",l:"Aporte mensal (R$)",t:"number",min:0},{k:"y",l:"Prazo (anos)",t:"number",min:1},{k:"r",l:"Taxa de rentabilidade (% a.a.)",t:"number",min:0}];
function simInv(){var tot=D.inv.reduce(function(s,x){return s+x.valor},0),avg=D.inv.length?D.inv.reduce(function(s,x){return s+(+x.taxa||0)},0)/D.inv.length:10;SF[0].v=tot;SF[1].v=300;SF[2].v=5;SF[3].v=+avg.toFixed(2);
 return '<div class="cd"><h2>Simular investimento</h2>'+formHTML("fs",SF,"Calcular")+'<div id="sr"></div><p class="nt">Agora você pode informar a taxa de juros/rentabilidade que quiser. O cálculo usa juros compostos e serve como estimativa.</p></div>'}
function fv(P,A,rate,y){var ar=rate/100,i=Math.pow(1+ar,1/12)-1,n=y*12;if(Math.abs(i)<1e-12)return P+A*n;return P*Math.pow(1+i,n)+A*((Math.pow(1+i,n)-1)/i)}
function simRun(){var f=$("#fs");if(!f)return;var o=read(f,SF);if(!o)return;var inv=o.p+o.a*o.y*12,fut=fv(o.p,o.a,o.r,o.y),gan=fut-inv,mi=Math.pow(1+o.r/100,1/12)-1;
 $("#sr").innerHTML='<div class="ks simks"><div class="k"><span>Total investido</span><b>'+brl(inv)+'</b></div><div class="k"><span>Taxa usada</span><b>'+num(o.r)+'% a.a.</b></div><div class="k"><span>Equivalente mensal</span><b>'+num(mi*100,3)+'% a.m.</b></div><div class="k hi"><span>Valor futuro estimado</span><b>'+brl(fut)+'</b></div></div><div class="cd simout"><h2>Resumo da projeção</h2><div class="bar"><span>Capital aplicado</span><div><i style="width:'+(inv>0?Math.max(8,inv/fut*100):0)+'%;background:var(--am)"></i></div><span>'+brl(inv)+'</span></div><div class="bar"><span>Rendimento estimado</span><div><i style="width:'+(fut>0?Math.max(8,gan/fut*100):0)+'%;background:var(--g)"></i></div><span>'+brl(gan)+'</span></div><p class="nt simnote">Em '+num(o.y,0)+' anos, com aporte mensal de <b>'+brl(o.a)+'</b>, o montante projetado é <b>'+brl(fut)+'</b>.</p></div>'}
function simWire(){$("#fs").addEventListener("submit",function(e){e.preventDefault();simRun()});simRun()}

var VF=[{k:"modelo",l:"Modelo",t:"text"},{k:"ano",l:"Ano",t:"number",min:1950},{k:"consumo",l:"Consumo (km/l)",t:"number"},{k:"km",l:"Km rodados por mês",t:"number"},{k:"preco",l:"Preço do litro (R$)",t:"number"}];
function vei(){var v=D.vei;VF.forEach(function(f){f.v=v?v[f.k]:null});
 $("#mn").innerHTML="<h1>Veículo e combustível</h1><div class=\"cd\">"+formHTML("fv",VF,"Salvar e estimar")+'</div><div class="cd" id="vr"></div>';
 function show(){var v=D.vei;$("#vr").innerHTML=v?'<h2>'+esc(v.modelo)+" "+v.ano+'</h2><div class="ks" style="margin:0"><div class="k"><span>Litros por mês</span><b>'+(v.km/v.consumo).toFixed(1).replace(".",",")+' L</b></div><div class="k hi"><span>Gasto por mês</span><b>'+brl(v.km/v.consumo*v.preco)+'</b></div><div class="k"><span>Custo por km</span><b>'+brl(v.preco/v.consumo)+'</b></div><div class="k"><span>Gasto por ano</span><b>'+brl(v.km/v.consumo*v.preco*12)+"</b></div></div>":'<p class="nt">Cadastre o veículo para estimar o gasto com combustível.</p>'}
 show();$("#fv").addEventListener("submit",function(e){e.preventDefault();var o=read(e.target,VF);if(!o)return;api("veiculo.php",{method:"POST",body:o}).then(function(r){D.vei=r.veiculo;show();toast("Veículo salvo.")}).catch(function(er){toast(er.message)})})}

function mk(d){return d.getFullYear()+"-"+("0"+(d.getMonth()+1)).slice(-2)}
function ms(){var a=[],n=new Date(),i,d;for(i=5;i>=0;i--){d=new Date(n.getFullYear(),n.getMonth()-i,1);a.push({k:mk(d),l:d.toLocaleDateString("pt-BR",{month:"short"}).replace(".",""),r:0,d:0})}
 D.tx.forEach(function(x){a.forEach(function(m){if(x.data.slice(0,7)===m.k){if(x.tipo==="receita")m.r+=x.valor;else m.d+=x.valor}})});return a}
function dash(){var m=ms(),R=0,Dd=0,cat={};D.tx.forEach(function(x){if(x.tipo==="receita")R+=x.valor;else{Dd+=x.valor;cat[x.cat]=(cat[x.cat]||0)+x.valor}});
 var div=D.div.reduce(function(s,x){return s+x.valor},0),inv=D.inv.reduce(function(s,x){return s+x.valor},0),cur=m[5],mx=Math.max.apply(null,m.map(function(x){return Math.max(x.r,x.d)}).concat([1]));
 var svg='<svg class="ch" viewBox="0 0 600 210" role="img" aria-label="Receitas e despesas dos últimos 6 meses">'+m.map(function(x,j){var x0=j*100+22,hr=x.r/mx*150,hd=x.d/mx*150;
 return '<rect x="'+x0+'" y="'+(170-hr)+'" width="26" height="'+hr+'" rx="5" fill="var(--g)"/><rect x="'+(x0+30)+'" y="'+(170-hd)+'" width="26" height="'+hd+'" rx="5" fill="var(--am)"/><text x="'+(x0+28)+'" y="194" text-anchor="middle" font-size="14" fill="var(--mut)">'+x.l+"</text>"}).join("")+'<line x1="0" x2="600" y1="171" y2="171" stroke="var(--ln)"/></svg>';
 var cs=Object.keys(cat).sort(function(a,b){return cat[b]-cat[a]}).slice(0,5),cm=cat[cs[0]]||1;
 var empty=!D.tx.length&&!D.div.length&&!D.inv.length&&!D.metas.length;
 $("#mn").innerHTML="<h1>Olá, "+esc(U.nome.split(" ")[0])+"</h1>"+(empty?'<div class="cd"><h2>Comece por aqui</h2><p class="nt" style="font-size:1rem;margin:0 0 14px">Cadastre suas receitas e despesas ou carregue dados de exemplo para conhecer o painel.</p><a class="btn p" href="#tx">Cadastrar lançamentos</a> <button class="btn o" id="sd">Carregar exemplo</button></div>':"")+
 '<div class="ks"><div class="k hi"><span>Saldo</span><b>'+brl(R-Dd)+'</b></div><div class="k"><span>Receitas do mês</span><b>'+brl(cur.r)+'</b></div><div class="k"><span>Despesas do mês</span><b>'+brl(cur.d)+'</b></div><div class="k"><span>Dívidas</span><b>'+brl(div)+'</b></div><div class="k"><span>Investido</span><b>'+brl(inv)+"</b></div></div>"+
 '<div class="cd"><h2>Receitas e despesas</h2>'+svg+'<div class="lg2"><span><b style="background:var(--g)"></b>Receitas</span><span><b style="background:var(--am)"></b>Despesas</span></div></div>'+
 '<div class="cd"><h2>Maiores categorias de despesa</h2>'+(cs.length?cs.map(function(c){return '<div class="bar"><span>'+esc(c)+'</span><div><i style="width:'+cat[c]/cm*100+'%"></i></div><span>'+brl(cat[c])+"</span></div>"}).join(""):'<p class="nt">Sem despesas cadastradas.</p>')+"</div>";
 var b=$("#sd");if(b)b.onclick=function(){b.disabled=true;seed().then(function(){toast("Dados de exemplo carregados.")}).catch(function(er){toast(er.message)})}}
function seed(){return api("exemplo.php",{method:"POST"}).then(function(){return start(U)})}

var P={normal:["Normal",19.9,["Receitas e despesas","Painel e gráficos","Dívidas, metas e investimentos","Veículo e combustível"]],premium:["Premium",39.9,["Tudo do plano Normal","Capitaly AI: análises e planos","Plano de pagamento de dívidas","Comparação de cenários"]]};
var pend=null;
function plano(){$("#mn").innerHTML="<h1>Seu plano</h1><div class=\"pl\">"+Object.keys(P).map(function(k){var p=P[k],on=U.plano===k;
 return '<div class="card'+(on?" on":"")+'"><h2>'+p[0]+(on?' <span class="tag">Atual</span>':"")+'</h2><div class="price">'+brl(p[1])+"<small>/mês</small></div><ul>"+p[2].map(function(x){return "<li>"+x+"</li>"}).join("")+"</ul>"+
 (on?"":'<button class="btn p" data-p="'+k+'">Assinar '+p[0]+"</button>")+"</div>"}).join("")+"</div>";
 $("#mn").onclick=function(e){var b=e.target.closest("[data-p]");if(b)buy(b.dataset.p)}}
function buy(k){pend=k;$("#dpt").textContent="Contratar "+P[k][0];$("#dpd").textContent="Você passará para o plano "+P[k][0]+" por "+brl(P[k][1])+"/mês.";$("#dp").showModal()}
$("#dpx").onclick=function(){$("#dp").close()};
$("#dp").addEventListener("click",function(e){if(e.target===this)this.close()});
$("#dpc").onclick=function(){api("plano.php",{method:"POST",body:{plano:pend}}).then(function(r){U.plano=r.usuario.plano;$("#dp").close();toast("Plano "+P[U.plano][0]+" ativado.");render()}).catch(function(er){toast(er.message)})};

var chat=[],busy=false;
function fmt(t){return esc(t).replace(/\*\*(.+?)\*\*/g,"<b>$1</b>").replace(/^[-*] /gm,"• ").replace(/\n/g,"<br>")}
function ia(){if(U.plano!=="premium"){$("#mn").innerHTML='<h1>Capitaly AI</h1><div class="cd lock"><h2>Recurso do plano Premium</h2><p>Análises das suas finanças, plano de pagamento de dívidas e comparação de cenários.</p><button class="btn p" id="up2">Conhecer o Premium</button></div>';$("#up2").onclick=function(){location.hash="plano"};return}
 var chips=["Analise minhas receitas e despesas","Monte um plano para quitar minhas dívidas","Como organizar minhas metas?","Compare cenários de investimento","Cadastrar uma dívida"];
 $("#mn").innerHTML='<h1>Capitaly AI</h1><div class="cd chat"><div id="msgs" aria-live="polite"></div><div class="chips">'+chips.map(function(c){return "<button>"+c+"</button>"}).join("")+'</div><form id="cf"><input id="ci" aria-label="Pergunta para a Capitaly AI" placeholder="Pergunte sobre suas finanças" autocomplete="off" maxlength="1000"><button class="btn p" id="cb">Enviar</button></form><p class="nt">A IA usa os dados que você cadastrou. Respostas são orientações gerais, não consultoria financeira.</p></div>';
 var box=$("#msgs");
 function add(c,h){var d=document.createElement("div");d.className="m "+c;d.innerHTML=h;box.appendChild(d);box.scrollTop=box.scrollHeight;return d}
 chat.forEach(function(m){add(m.role==="user"?"u":"a",fmt(m.content))});
 if(!chat.length)add("a","Olá! Eu analiso o que você cadastrou no Capitaly. Escolha uma sugestão ou escreva sua pergunta.");
 function ask(q){if(busy||!q)return;busy=true;$("#cb").disabled=true;add("u",esc(q));var el=add("a","Pensando…");
  api("chat.php",{method:"POST",body:{pergunta:q,historico:chat.slice(-6)}}).then(function(r){el.innerHTML=fmt(r.resposta);chat.push({role:"user",content:q},{role:"assistant",content:r.resposta});if(r.alterou){refresh().then(function(){toast("Dados atualizados pela Capitaly AI.")}).catch(function(){})}})
  .catch(function(er){el.textContent=er.message||"Não consegui responder agora."})
  .then(function(){busy=false;var b=$("#cb");if(b)b.disabled=false})}
 $("#cf").addEventListener("submit",function(e){e.preventDefault();var i=$("#ci"),q=i.value.trim();i.value="";ask(q)});
 Array.prototype.forEach.call(document.querySelectorAll(".chips button"),function(b){b.onclick=function(){ask(b.textContent)}})}
function adm(){$("#mn").innerHTML='<h1>Administração</h1><div class="cd"><h2 id="ah">Contas</h2><ul class="ls" id="al"><li class="em">Carregando…</li></ul></div>';
 function load(){api("admin.php").then(function(r){var us=r.usuarios;$("#ah").textContent="Contas cadastradas ("+us.length+")";
  $("#al").innerHTML=us.map(function(x){return '<li><div><b>'+esc(x.nome)+(x.admin?' <span class="tag">Admin</span>':'')+'</b><small>'+esc(x.email)+' · Plano '+P[x.plano][0]+'</small></div><button class="btn o" data-t="'+x.id+'" data-np="'+(x.plano==="premium"?"normal":"premium")+'">'+(x.plano==="premium"?"Rebaixar":"Tornar Premium")+'</button>'+(x.admin?'<span></span>':'<button class="x" data-r="'+x.id+'" aria-label="Remover conta">×</button>')+'</li>'}).join("")})
  .catch(function(er){$("#al").innerHTML='<li class="em">'+esc(er.message)+"</li>"})}
 load();
 $("#mn").onclick=function(e){var t=e.target.closest("[data-t]"),r=e.target.closest("[data-r]");
  if(t)api("admin.php",{method:"POST",body:{id:+t.dataset.t,plano:t.dataset.np}}).then(function(){toast("Plano atualizado.");load()}).catch(function(er){toast(er.message)});
  else if(r)api("admin.php?id="+r.dataset.r,{method:"DELETE"}).then(function(){toast("Conta removida.");load()}).catch(function(er){toast(er.message)})}}

var NAV=[["dash","Painel"],["tx","Lançamentos"],["div","Dívidas"],["inv","Investimentos"],["metas","Metas"],["vei","Veículo"],["ia","Capitaly AI"],["plano","Plano"]];
function render(){if(!U)return;var h=location.hash.slice(1),N=U.admin?NAV.concat([["admin","Admin"]]):NAV;V=N.some(function(n){return n[0]===h})?h:"dash";
 $("#nv").innerHTML=N.map(function(n){return '<a href="#'+n[0]+'"'+(n[0]===V?' aria-current="page"':"")+">"+ic(n[0])+"<span>"+n[1]+"</span></a>"}).join("");
 $("#un").textContent=U.nome;$("#up").textContent="Plano "+P[U.plano][0];$("#mn").onclick=null;
 if(V==="dash")dash();else if(V==="vei")vei();else if(V==="ia")ia();else if(V==="plano")plano();else if(V==="admin")adm();else crud(V);
 window.scrollTo(0,0);var a=$('#nv [aria-current="page"]');if(a&&a.scrollIntoView)a.scrollIntoView({inline:"center",block:"nearest"})}
window.addEventListener("hashchange",render);

api("auth.php").then(function(r){if(r.usuario)start(r.usuario);else{$("#auth").hidden=false;authForm()}}).catch(function(){$("#auth").hidden=false;authForm();toast("Servidor indisponível. Verifique o Apache e o MySQL.")});
})();
