CREATE DATABASE IF NOT EXISTS capitaly
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE capitaly;

DROP VIEW  IF EXISTS vw_resumo_mensal;
DROP TABLE IF EXISTS analises_ia, metas, veiculos, investimentos, dividas,
                     lancamentos, assinaturas, usuarios, planos;

CREATE TABLE planos (
  id          TINYINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  codigo      VARCHAR(20)   NOT NULL UNIQUE,
  nome        VARCHAR(40)   NOT NULL,
  preco_mensal DECIMAL(8,2) NOT NULL CHECK (preco_mensal >= 0),
  usa_ia      BOOLEAN       NOT NULL DEFAULT FALSE
) ENGINE=InnoDB;

CREATE TABLE usuarios (
  id          INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  nome        VARCHAR(120)  NOT NULL,
  email       VARCHAR(160)  NOT NULL UNIQUE,
  senha_hash  VARCHAR(255)  NOT NULL,
  plano_id    TINYINT UNSIGNED NOT NULL DEFAULT 1,
  is_admin    BOOLEAN       NOT NULL DEFAULT FALSE,
  criado_em   TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_usuario_plano FOREIGN KEY (plano_id) REFERENCES planos(id)
) ENGINE=InnoDB;

CREATE TABLE assinaturas (
  id          INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  usuario_id  INT UNSIGNED NOT NULL,
  plano_id    TINYINT UNSIGNED NOT NULL,
  valor       DECIMAL(8,2) NOT NULL CHECK (valor >= 0),
  forma_pagamento ENUM('pix','cartao') NOT NULL,
  status      ENUM('ativa','cancelada') NOT NULL DEFAULT 'ativa',
  inicio      DATE NOT NULL,
  fim         DATE NULL,
  CONSTRAINT fk_ass_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  CONSTRAINT fk_ass_plano   FOREIGN KEY (plano_id)   REFERENCES planos(id),
  INDEX idx_ass_usuario (usuario_id, status)
) ENGINE=InnoDB;

CREATE TABLE lancamentos (
  id          INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  usuario_id  INT UNSIGNED NOT NULL,
  tipo        ENUM('receita','despesa') NOT NULL,
  descricao   VARCHAR(160) NOT NULL,
  categoria   VARCHAR(60)  NOT NULL,
  valor       DECIMAL(12,2) NOT NULL CHECK (valor > 0),
  data        DATE NOT NULL,
  criado_em   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_lanc_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  INDEX idx_lanc_usuario_data (usuario_id, data),
  INDEX idx_lanc_usuario_cat  (usuario_id, tipo, categoria)
) ENGINE=InnoDB;

CREATE TABLE dividas (
  id          INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  usuario_id  INT UNSIGNED NOT NULL,
  descricao   VARCHAR(160) NOT NULL,
  valor_total DECIMAL(12,2) NOT NULL CHECK (valor_total > 0),
  juros_mensal DECIMAL(6,2) NOT NULL DEFAULT 0 CHECK (juros_mensal >= 0),
  parcelas    SMALLINT UNSIGNED NOT NULL CHECK (parcelas >= 1),
  vencimento  DATE NOT NULL,
  status      ENUM('em dia','atrasada','negociando','quitada') NOT NULL DEFAULT 'em dia',
  criado_em   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_div_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  INDEX idx_div_usuario (usuario_id, juros_mensal)
) ENGINE=InnoDB;

CREATE TABLE investimentos (
  id          INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  usuario_id  INT UNSIGNED NOT NULL,
  tipo        VARCHAR(40)  NOT NULL,
  valor       DECIMAL(12,2) NOT NULL CHECK (valor > 0),
  data        DATE NOT NULL,
  rentabilidade_anual DECIMAL(6,2) NOT NULL DEFAULT 0 CHECK (rentabilidade_anual >= 0),
  criado_em   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_inv_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  INDEX idx_inv_usuario (usuario_id)
) ENGINE=InnoDB;

CREATE TABLE veiculos (
  id          INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  usuario_id  INT UNSIGNED NOT NULL UNIQUE,
  modelo      VARCHAR(80)  NOT NULL,
  ano         SMALLINT UNSIGNED NOT NULL CHECK (ano >= 1950),
  consumo_km_l DECIMAL(5,2) NOT NULL CHECK (consumo_km_l > 0),
  km_mensal   INT UNSIGNED NOT NULL CHECK (km_mensal > 0),
  preco_litro DECIMAL(6,2) NOT NULL CHECK (preco_litro > 0),
  CONSTRAINT fk_vei_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE metas (
  id          INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  usuario_id  INT UNSIGNED NOT NULL,
  objetivo    VARCHAR(160) NOT NULL,
  valor_atual DECIMAL(12,2) NOT NULL DEFAULT 0 CHECK (valor_atual >= 0),
  valor_alvo  DECIMAL(12,2) NOT NULL CHECK (valor_alvo > 0),
  prazo       DATE NOT NULL,
  criado_em   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_meta_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  INDEX idx_meta_usuario (usuario_id, prazo)
) ENGINE=InnoDB;

CREATE TABLE analises_ia (
  id          INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  usuario_id  INT UNSIGNED NOT NULL,
  pergunta    TEXT NOT NULL,
  resposta    MEDIUMTEXT NOT NULL,
  criado_em   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_ia_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  INDEX idx_ia_usuario (usuario_id, criado_em)
) ENGINE=InnoDB;

CREATE VIEW vw_resumo_mensal AS
SELECT usuario_id,
       DATE_FORMAT(data, '%Y-%m') AS mes,
       SUM(CASE WHEN tipo = 'receita' THEN valor ELSE 0 END) AS receitas,
       SUM(CASE WHEN tipo = 'despesa' THEN valor ELSE 0 END) AS despesas,
       SUM(CASE WHEN tipo = 'receita' THEN valor ELSE -valor END) AS saldo
FROM lancamentos
GROUP BY usuario_id, DATE_FORMAT(data, '%Y-%m');

INSERT INTO planos (codigo, nome, preco_mensal, usa_ia) VALUES
  ('normal',  'Normal',  19.90, FALSE),
  ('premium', 'Premium', 39.90, TRUE);

INSERT INTO usuarios (nome, email, senha_hash, plano_id, is_admin) VALUES
  ('Administrador Capitaly', 'admin@capitaly.com',
   '$2y$10$MqKfJZ/f2wuKI0nDo7Vl7ezVOKN47YMkF/r70i/K/89iO/Bytn5pq', 2, TRUE);

INSERT INTO lancamentos (usuario_id, tipo, descricao, categoria, valor, data) VALUES
  (1,'receita','Salário','Salário',4500.00,'2026-11-05'),
  (1,'despesa','Aluguel','Moradia',1200.00,'2026-11-05'),
  (1,'despesa','Mercado','Alimentação',620.00,'2026-11-12'),
  (1,'despesa','Transporte','Transporte',310.00,'2026-11-15'),
  (1,'despesa','Lazer','Lazer',240.00,'2026-11-20'),
  (1,'receita','Salário','Salário',4500.00,'2026-10-05'),
  (1,'despesa','Aluguel','Moradia',1200.00,'2026-10-05'),
  (1,'despesa','Mercado','Alimentação',580.00,'2026-10-12');

INSERT INTO dividas (usuario_id, descricao, valor_total, juros_mensal, parcelas, vencimento, status) VALUES
  (1,'Cartão de crédito',1800.00,12.00,6,'2026-12-10','atrasada'),
  (1,'Empréstimo pessoal',3500.00,3.20,18,'2026-12-20','em dia');

INSERT INTO investimentos (usuario_id, tipo, valor, data, rentabilidade_anual) VALUES
  (1,'Renda fixa',2000.00,'2026-11-01',10.50);

INSERT INTO metas (usuario_id, objetivo, valor_atual, valor_alvo, prazo) VALUES
  (1,'Reserva de emergência',1500.00,9000.00,'2027-11-01');

INSERT INTO veiculos (usuario_id, modelo, ano, consumo_km_l, km_mensal, preco_litro) VALUES
  (1,'Honda Civic',2018,11.00,900,5.89);

INSERT INTO assinaturas (usuario_id, plano_id, valor, forma_pagamento, status, inicio) VALUES
  (1,2,39.90,'pix','ativa','2026-11-01');

