<?php

header('Content-Type: text/html; charset=utf-8');
require __DIR__ . '/config.php';
function status_item($ok, $yes, $no) { return '<li><strong style="color:'.($ok?'#0B5D3B':'#B42336').'">'.($ok?'OK':'ATENÇÃO').'</strong> — '.htmlspecialchars($ok?$yes:$no, ENT_QUOTES, 'UTF-8').'</li>'; }
$phpOk = version_compare(PHP_VERSION, '8.1', '>=');
$pdoOk = extension_loaded('pdo_mysql');
$mbOk = extension_loaded('mbstring');
$curlOk = extension_loaded('curl');
$dbOk = false; $schemaOk = false; $message = '';
if ($pdoOk) {
    try {
        $pdo = new PDO('mysql:host='.DB_HOST.';port='.DB_PORT.';dbname='.DB_NAME.';charset=utf8mb4', DB_USER, DB_PASS, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
        $dbOk=true;
        $required=['usuarios','planos','lancamentos','dividas','investimentos','metas','veiculos','assinaturas','analises_ia'];
        $tables=$pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
        $schemaOk = count(array_diff($required,$tables))===0;
    } catch (Throwable $e) { error_log('Capitaly diagnostico: '.$e->getMessage()); $message='Verifique se MySQL está iniciado, se o banco capitaly foi importado e se api/config.php tem usuário e senha corretos. Consulte o log do Apache para o detalhe técnico.'; }
}
echo '<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Diagnóstico Capitaly</title><body style="font:16px/1.6 Segoe UI,Arial,sans-serif;max-width:780px;margin:50px auto;padding:20px;color:#183C2B"><h1>Diagnóstico do Capitaly</h1><p>Verificação de dependências do servidor local.</p><ul>';
echo status_item($phpOk,'PHP compatível (8.1+)','Atualize o PHP para versão 8.1 ou superior.');
echo status_item($pdoOk,'Extensão pdo_mysql ativa','Ative extension=pdo_mysql no php.ini do Apache.');
echo status_item($mbOk,'Extensão mbstring ativa','Ative extension=mbstring no php.ini do Apache.');
echo status_item($curlOk,'Extensão curl ativa para IA','Ative extension=curl no php.ini do Apache para usar a IA.');
echo status_item($dbOk,'Conexão ao MySQL estabelecida','Sem conexão MySQL.');
echo status_item($schemaOk,'Tabelas principais encontradas','Importe capitaly.sql no phpMyAdmin (ATENÇÃO: a importação recria as tabelas).');
echo '</ul><p>'.htmlspecialchars($message, ENT_QUOTES, 'UTF-8').'</p><p><a href="../app.html" style="color:#0B5D3B">Abrir aplicativo</a></p></body></html>';
