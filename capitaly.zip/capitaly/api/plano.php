<?php
require __DIR__ . '/lib.php';

$u = exigir_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('Método não permitido.', 405);
$in = body();
$pdo = db();

$s = $pdo->prepare('SELECT id, preco_mensal FROM planos WHERE codigo = ?');
$s->execute([(string)($in['plano'] ?? '')]);
$p = $s->fetch();
if (!$p) fail('Plano inválido.', 422);
$pg = in_array($in['pagamento'] ?? 'pix', ['pix', 'cartao'], true) ? $in['pagamento'] : 'pix';

$pdo->beginTransaction();
$pdo->prepare("UPDATE assinaturas SET status = 'cancelada', fim = CURDATE() WHERE usuario_id = ? AND status = 'ativa'")->execute([$u['id']]);
$pdo->prepare("INSERT INTO assinaturas (usuario_id, plano_id, valor, forma_pagamento, status, inicio) VALUES (?, ?, ?, ?, 'ativa', CURDATE())")
    ->execute([$u['id'], $p['id'], $p['preco_mensal'], $pg]);
$pdo->prepare('UPDATE usuarios SET plano_id = ? WHERE id = ?')->execute([$p['id'], $u['id']]);
$pdo->commit();
out(['usuario' => usuario_logado()]);
