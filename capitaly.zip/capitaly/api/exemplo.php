<?php
require __DIR__ . '/lib.php';

$u = exigir_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('Método não permitido.', 405);
$pdo = db();
$id = $u['id'];

function vazia(PDO $pdo, string $t, int $id): bool {
    $s = $pdo->prepare("SELECT COUNT(*) FROM `$t` WHERE usuario_id = ?");
    $s->execute([$id]);
    return (int)$s->fetchColumn() === 0;
}

$pdo->beginTransaction();
if (vazia($pdo, 'lancamentos', $id)) {
    $ins = $pdo->prepare('INSERT INTO lancamentos (usuario_id, tipo, descricao, categoria, valor, data) VALUES (?, ?, ?, ?, ?, ?)');
    $desp = [['Aluguel', 'Moradia', 1200, 5], ['Mercado', 'Alimentação', 620, 12], ['Transporte', 'Transporte', 310, 15],
             ['Lazer', 'Lazer', 240, 20], ['Internet e celular', 'Contas', 180, 8]];
    for ($i = 0; $i < 6; $i++) {
        $base = new DateTime('first day of this month');
        $base->modify("-$i month");
        $ins->execute([$id, 'receita', 'Salário', 'Salário', 4500, $base->format('Y-m-05')]);
        foreach ($desp as $d) $ins->execute([$id, 'despesa', $d[0], $d[1], $d[2] + (($i * 37) % 90), $base->format('Y-m-') . sprintf('%02d', $d[3])]);
    }
}
$prox = new DateTime('first day of next month');
if (vazia($pdo, 'dividas', $id)) {
    $ins = $pdo->prepare('INSERT INTO dividas (usuario_id, descricao, valor_total, juros_mensal, parcelas, vencimento, status) VALUES (?, ?, ?, ?, ?, ?, ?)');
    $ins->execute([$id, 'Cartão de crédito', 1800, 12, 6, $prox->format('Y-m-10'), 'atrasada']);
    $ins->execute([$id, 'Empréstimo pessoal', 3500, 3.2, 18, $prox->format('Y-m-20'), 'em dia']);
}
if (vazia($pdo, 'investimentos', $id)) {
    $pdo->prepare('INSERT INTO investimentos (usuario_id, tipo, valor, data, rentabilidade_anual) VALUES (?, ?, ?, CURDATE(), ?)')
        ->execute([$id, 'Renda fixa', 2000, 10.5]);
}
if (vazia($pdo, 'metas', $id)) {
    $pdo->prepare('INSERT INTO metas (usuario_id, objetivo, valor_atual, valor_alvo, prazo) VALUES (?, ?, ?, ?, DATE_ADD(CURDATE(), INTERVAL 12 MONTH))')
        ->execute([$id, 'Reserva de emergência', 1500, 9000]);
}
if (vazia($pdo, 'veiculos', $id)) {
    $pdo->prepare('INSERT INTO veiculos (usuario_id, modelo, ano, consumo_km_l, km_mensal, preco_litro) VALUES (?, ?, ?, ?, ?, ?)')
        ->execute([$id, 'Honda Civic', 2018, 11, 900, 5.89]);
}
$pdo->commit();
out(['ok' => true]);
