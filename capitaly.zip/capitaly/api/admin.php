<?php
require __DIR__ . '/lib.php';

$adm = exigir_admin();
$pdo = db();

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        $r = $pdo->query('SELECT u.id, u.nome, u.email, u.is_admin, p.codigo AS plano
                          FROM usuarios u JOIN planos p ON p.id = u.plano_id ORDER BY u.id')->fetchAll();
        out(['usuarios' => array_map(fn($x) => [
            'id' => (int)$x['id'], 'nome' => $x['nome'], 'email' => $x['email'],
            'admin' => (bool)$x['is_admin'], 'plano' => $x['plano'],
        ], $r)]);
    case 'POST':
        $in = body();
        $s = $pdo->prepare('UPDATE usuarios SET plano_id = (SELECT id FROM planos WHERE codigo = ?) WHERE id = ?');
        $cod = (string)($in['plano'] ?? '');
        if (!in_array($cod, ['normal', 'premium'], true)) fail('Plano inválido.', 422);
        $s->execute([$cod, (int)($in['id'] ?? 0)]);
        out(['ok' => true]);
    case 'DELETE':
        $id = (int)($_GET['id'] ?? 0);
        if ($id === $adm['id']) fail('Você não pode remover a própria conta.', 422);
        $s = $pdo->prepare('DELETE FROM usuarios WHERE id = ? AND is_admin = 0');
        $s->execute([$id]);
        if ($s->rowCount() === 0) fail('Conta não encontrada.', 404);
        out(['ok' => true]);
    default:
        fail('Método não permitido.', 405);
}
