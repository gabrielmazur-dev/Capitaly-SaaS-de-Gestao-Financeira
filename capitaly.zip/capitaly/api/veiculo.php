<?php
require __DIR__ . '/lib.php';

$u = exigir_login();
$campos = [
    'modelo'  => ['col' => 'modelo', 't' => 'str', 'max' => 80],
    'ano'     => ['col' => 'ano', 't' => 'int', 'min' => 1950, 'max' => 2100],
    'consumo' => ['col' => 'consumo_km_l', 't' => 'num', 'max' => 100],
    'km'      => ['col' => 'km_mensal', 't' => 'int', 'min' => 1, 'max' => 100000],
    'preco'   => ['col' => 'preco_litro', 't' => 'num', 'max' => 100],
];
$sel = selecionar($campos);
$pdo = db();

function veiculo_atual(PDO $pdo, string $sel, array $campos, int $uid): ?array {
    $s = $pdo->prepare("SELECT $sel FROM veiculos WHERE usuario_id = ?");
    $s->execute([$uid]);
    $r = $s->fetch();
    return $r ? saida($r, $campos) : null;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') out(['veiculo' => veiculo_atual($pdo, $sel, $campos, $u['id'])]);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('Método não permitido.', 405);

$d = validar($campos, body());
$existe = $pdo->prepare('SELECT 1 FROM veiculos WHERE usuario_id = ?');
$existe->execute([$u['id']]);
if ($existe->fetch()) {
    $pdo->prepare('UPDATE veiculos SET modelo = ?, ano = ?, consumo_km_l = ?, km_mensal = ?, preco_litro = ? WHERE usuario_id = ?')
        ->execute([$d['modelo'], $d['ano'], $d['consumo'], $d['km'], $d['preco'], $u['id']]);
} else {
    $pdo->prepare('INSERT INTO veiculos (usuario_id, modelo, ano, consumo_km_l, km_mensal, preco_litro) VALUES (?, ?, ?, ?, ?, ?)')
        ->execute([$u['id'], $d['modelo'], $d['ano'], $d['consumo'], $d['km'], $d['preco']]);
}
out(['veiculo' => veiculo_atual($pdo, $sel, $campos, $u['id'])]);
