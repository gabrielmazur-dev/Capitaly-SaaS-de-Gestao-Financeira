<?php
require __DIR__ . '/lib.php';
crud('dividas');
