<?php

define('DB_HOST', getenv('CAPITALY_DB_HOST') ?: '127.0.0.1');
define('DB_PORT', getenv('CAPITALY_DB_PORT') ?: '3306');
define('DB_NAME', getenv('CAPITALY_DB_NAME') ?: 'capitaly');
define('DB_USER', getenv('CAPITALY_DB_USER') ?: 'root');
define('DB_PASS', getenv('CAPITALY_DB_PASS') !== false ? getenv('CAPITALY_DB_PASS') : '');

define('GEMINI_API_KEY', getenv('GEMINI_API_KEY') ?: 'AQ.Ab8RN6JUVoKszncnBiP-K4ZlcH8nR1RehvaIanKeN7I2jj53_g');

define('GEMINI_MODEL', 'gemini-3.5-flash-lite');

define('CA_BUNDLE', '');
