<?php
require __DIR__ . '/lib.php';

$m = $_SERVER['REQUEST_METHOD'];
$acao = $_GET['acao'] ?? '';

if ($m === 'GET') out(['usuario' => usuario_logado()]);
guard();
if ($m !== 'POST') fail('Método não permitido.', 405);
$in = body();

if ($acao === 'sair') {
    $_SESSION = [];
    session_destroy();
    out(['ok' => true]);
}

$email = mb_strtolower(trim((string)($in['email'] ?? '')));
$senha = (string)($in['senha'] ?? '');

if ($acao === 'cadastro') {
    $nome = trim((string)($in['nome'] ?? ''));
    $e = [];
    if (count(preg_split('/\s+/', $nome, -1, PREG_SPLIT_NO_EMPTY)) < 2 || mb_strlen($nome) > 120) $e['nome'] = 'Informe nome e sobrenome.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 160) $e['email'] = 'Use um e-mail válido.';
    if (strlen($senha) < 8 || !preg_match('/[A-Za-z]/', $senha) || !preg_match('/\d/', $senha)) $e['senha'] = 'Use 8 caracteres ou mais, com letras e números.';
    if (($in['conf'] ?? '') !== $senha) $e['conf'] = 'As senhas não conferem.';
    if ($e) fail('Dados inválidos.', 422, $e);

    $s = db()->prepare('SELECT 1 FROM usuarios WHERE email = ?');
    $s->execute([$email]);
    if ($s->fetch()) fail('Já existe uma conta com esse e-mail.', 409, ['email' => 'Já existe uma conta com esse e-mail. Entre com a senha.']);

    db()->prepare("INSERT INTO usuarios (nome, email, senha_hash, plano_id)
                   VALUES (?, ?, ?, (SELECT id FROM planos WHERE codigo = 'normal'))")
        ->execute([$nome, $email, password_hash($senha, PASSWORD_DEFAULT)]);
    session_regenerate_id(true);
    $_SESSION['uid'] = (int)db()->lastInsertId();
    out(['usuario' => usuario_logado()], 201);
}

if ($acao === 'login') {
    $s = db()->prepare('SELECT id, senha_hash FROM usuarios WHERE email = ?');
    $s->execute([$email]);
    $u = $s->fetch();
    if (!$u || !password_verify($senha, $u['senha_hash'])) {
        usleep(400000);
        fail('E-mail ou senha incorretos.', 401);
    }
    session_regenerate_id(true);
    $_SESSION['uid'] = (int)$u['id'];
    out(['usuario' => usuario_logado()]);
}

fail('Ação inválida.');
