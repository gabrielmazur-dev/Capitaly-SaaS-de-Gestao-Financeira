<?php
declare(strict_types=1);
require __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

session_name('capitaly');
session_set_cookie_params([
    'lifetime' => 0, 'path' => '/', 'httponly' => true,
    'samesite' => 'Lax', 'secure' => !empty($_SERVER['HTTPS']),
]);
session_start();

function out(array $data, int $code = 200): never {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}
function fail(string $msg, int $code = 400, array $campos = []): never {
    out(['erro' => $msg, 'campos' => (object)$campos], $code);
}
function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO('mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        } catch (Throwable $e) {
            error_log('Erro de conexão MySQL: ' . $e->getMessage());
            $codigo = ($e instanceof PDOException) ? (string)$e->getCode() : '';
            if (str_contains($e->getMessage(), 'could not find driver')) {
                fail('Extensão pdo_mysql não habilitada no PHP do Apache. Ative-a no php.ini e reinicie o Apache.', 503);
            }
            if (in_array($codigo, ['1045', '28000'], true) || str_contains($e->getMessage(), 'Access denied')) {
                fail('Acesso ao MySQL negado. Confira DB_USER e DB_PASS em api/config.php.', 503);
            }
            if ($codigo === '1049' || str_contains($e->getMessage(), 'Unknown database')) {
                fail('Banco capitaly não encontrado. Importe capitaly.sql no phpMyAdmin.', 503);
            }
            if (in_array($codigo, ['2002', '2003'], true) || str_contains($e->getMessage(), 'Connection refused')) {
                fail('MySQL indisponível. Inicie o MySQL no XAMPP e confira DB_HOST/DB_PORT em api/config.php.', 503);
            }
            fail('Não foi possível conectar ao banco. Abra api/diagnostico.php para identificar a causa.', 503);
        }
    }
    return $pdo;
}

function guard(): void {
    if ($_SERVER['REQUEST_METHOD'] !== 'GET' && ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') !== 'capitaly') {
        fail('Requisição inválida.', 403);
    }
}
function body(): array {
    $raw = file_get_contents('php://input');
    if ($raw === false || $raw === '') return [];
    $j = json_decode($raw, true);
    if (!is_array($j)) fail('Corpo da requisição inválido.');
    return $j;
}
function usuario_logado(): ?array {
    if (empty($_SESSION['uid'])) return null;
    $s = db()->prepare('SELECT u.id, u.nome, u.email, u.is_admin, p.codigo AS plano
                        FROM usuarios u JOIN planos p ON p.id = u.plano_id WHERE u.id = ?');
    $s->execute([$_SESSION['uid']]);
    $u = $s->fetch();
    if (!$u) { $_SESSION = []; return null; }
    return ['id' => (int)$u['id'], 'nome' => $u['nome'], 'email' => $u['email'],
            'admin' => (bool)$u['is_admin'], 'plano' => $u['plano']];
}
function exigir_login(): array {
    guard();
    $u = usuario_logado();
    if (!$u) fail('Sessão expirada. Entre novamente.', 401);
    return $u;
}
function exigir_admin(): array {
    $u = exigir_login();
    if (!$u['admin']) fail('Acesso restrito ao administrador.', 403);
    return $u;
}

function validar_erros(array $campos, array $in): array {
    $d = []; $e = [];
    foreach ($campos as $k => $c) {
        $v = $in[$k] ?? null;
        switch ($c['t']) {
            case 'str':
                $v = is_string($v) ? trim($v) : '';
                if ($v === '') $e[$k] = 'Campo obrigatório.';
                elseif (mb_strlen($v) > $c['max']) $e[$k] = 'Máximo de ' . $c['max'] . ' caracteres.';
                break;
            case 'num': case 'int':
                if (!is_numeric($v)) { $e[$k] = 'Informe um número.'; break; }
                $v = (float)$v;
                $min = $c['min'] ?? 0.01; $max = $c['max'] ?? 1e9;
                if ($v < $min) $e[$k] = 'Use um valor a partir de ' . $min . '.';
                elseif ($v > $max) $e[$k] = 'Valor acima do permitido.';
                elseif ($c['t'] === 'int') $v = (int)round($v);
                break;
            case 'date':
                $ok = is_string($v) && preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $v, $m) && checkdate((int)$m[2], (int)$m[3], (int)$m[1]);
                if (!$ok) $e[$k] = 'Informe uma data válida.';
                break;
            case 'enum':
                if (!in_array($v, $c['o'], true)) $e[$k] = 'Opção inválida.';
                break;
        }
        $d[$k] = $v;
    }
    return [$d, $e];
}
function validar(array $campos, array $in): array {
    [$d, $e] = validar_erros($campos, $in);
    if ($e) fail('Dados inválidos.', 422, $e);
    return $d;
}
function saida(array $row, array $campos): array {
    $o = ['id' => (int)$row['id']];
    foreach ($campos as $k => $c) {
        $v = $row[$k];
        $o[$k] = $c['t'] === 'num' ? (float)$v : ($c['t'] === 'int' ? (int)$v : (string)$v);
    }
    return $o;
}
function selecionar(array $campos): string {
    $p = [];
    foreach ($campos as $k => $c) $p[] = '`' . $c['col'] . '` AS `' . $k . '`';
    return 'id, ' . implode(', ', $p);
}

const RECURSOS = [
    'lancamentos' => ['ordem' => '`data` DESC, id DESC', 'campos' => [
        'tipo'  => ['col' => 'tipo', 't' => 'enum', 'o' => ['receita', 'despesa']],
        'desc'  => ['col' => 'descricao', 't' => 'str', 'max' => 160],
        'cat'   => ['col' => 'categoria', 't' => 'str', 'max' => 60],
        'valor' => ['col' => 'valor', 't' => 'num'],
        'data'  => ['col' => 'data', 't' => 'date'],
    ]],
    'dividas' => ['ordem' => 'juros_mensal DESC, id DESC', 'campos' => [
        'desc'     => ['col' => 'descricao', 't' => 'str', 'max' => 160],
        'valor'    => ['col' => 'valor_total', 't' => 'num'],
        'juros'    => ['col' => 'juros_mensal', 't' => 'num', 'min' => 0, 'max' => 1000],
        'parcelas' => ['col' => 'parcelas', 't' => 'int', 'min' => 1, 'max' => 600],
        'venc'     => ['col' => 'vencimento', 't' => 'date'],
        'status'   => ['col' => 'status', 't' => 'enum', 'o' => ['em dia', 'atrasada', 'negociando']],
    ]],
    'investimentos' => ['ordem' => '`data` DESC, id DESC', 'campos' => [
        'tipo'  => ['col' => 'tipo', 't' => 'str', 'max' => 40],
        'valor' => ['col' => 'valor', 't' => 'num'],
        'data'  => ['col' => 'data', 't' => 'date'],
        'taxa'  => ['col' => 'rentabilidade_anual', 't' => 'num', 'min' => 0, 'max' => 1000],
    ]],
    'metas' => ['ordem' => 'prazo ASC, id ASC', 'campos' => [
        'obj'   => ['col' => 'objetivo', 't' => 'str', 'max' => 160],
        'atual' => ['col' => 'valor_atual', 't' => 'num', 'min' => 0],
        'alvo'  => ['col' => 'valor_alvo', 't' => 'num'],
        'prazo' => ['col' => 'prazo', 't' => 'date'],
    ]],
];

function crud(string $r): void {
    $cfg = RECURSOS[$r];
    $u = exigir_login();
    $campos = $cfg['campos'];
    $sel = selecionar($campos);
    $pdo = db();
    switch ($_SERVER['REQUEST_METHOD']) {
        case 'GET':
            $s = $pdo->prepare("SELECT $sel FROM `$r` WHERE usuario_id = ? ORDER BY {$cfg['ordem']} LIMIT 1000");
            $s->execute([$u['id']]);
            out(['itens' => array_map(fn($row) => saida($row, $campos), $s->fetchAll())]);
        case 'POST':
            $d = validar($campos, body());
            $cols = array_map(fn($k) => '`' . $campos[$k]['col'] . '`', array_keys($campos));
            $pdo->prepare("INSERT INTO `$r` (usuario_id, " . implode(', ', $cols) . ') VALUES (?' . str_repeat(', ?', count($cols)) . ')')
                ->execute(array_merge([$u['id']], array_values($d)));
            $id = (int)$pdo->lastInsertId();
            $s = $pdo->prepare("SELECT $sel FROM `$r` WHERE id = ? AND usuario_id = ?");
            $s->execute([$id, $u['id']]);
            out(['item' => saida($s->fetch(), $campos)], 201);
        case 'DELETE':
            $id = (int)($_GET['id'] ?? 0);
            $s = $pdo->prepare("DELETE FROM `$r` WHERE id = ? AND usuario_id = ?");
            $s->execute([$id, $u['id']]);
            if ($s->rowCount() === 0) fail('Registro não encontrado.', 404);
            out(['ok' => true]);
        default:
            fail('Método não permitido.', 405);
    }
}
